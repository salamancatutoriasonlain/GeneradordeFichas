GENERADOR DE FICHAS SALAMANCA — versión para Mac OS X 10.5 (Leopard) y posteriores
SALAMANCA Tutorías Online · +34 609 975 502 · sosclases@hotmail.com
=====================================================================================

Qué hace
--------
Genera fichas y exámenes autocorregibles de matemáticas (archivos HTML con tu imagen
corporativa, tu teléfono y tu correo). Eliges el curso (de 1.º de ESO a 2.º de
Bachillerato), los temas, la dificultad y el número de ejercicios. La misma semilla
produce siempre la misma ficha. También genera la hoja de soluciones para el profesor.

Compilar e instalar (en el G5, con las herramientas de desarrollo de Xcode instaladas)
------------------------------------------------------------------------------------
  Terminal:
      cd GeneradorFichas_G5
      make app                  # crea build/GeneradorFichas.app
      make run                  # (opcional) la abre para probarla
      sudo make install         # la copia a /Applications

  Sin permisos de administrador:
      mkdir -p ~/Applications
      make install PREFIX=$HOME/Applications

  Otras órdenes:  make uninstall   ·   make clean   ·   make dmg

  Si hiciera falta forzar la arquitectura:   make app ARCH="-arch ppc"

Uso
---
1. Elige el curso; se cargan sus temas (puedes marcar o desmarcar los que quieras).
2. Ajusta dificultad, tipo (ficha o examen), número de ejercicios, reintentos y título.
3. «Generar y abrir en el navegador» crea la ficha y la abre con tu navegador
   predeterminado. «Guardar ficha…» y «Guardar soluciones…» la guardan donde quieras.
4. Las fichas se envían a los alumnos como archivos .html; el botón «Enviar nota» de la
   ficha usa el correo sosclases@hotmail.com.

Notas
-----
* La aplicación en sí solo necesita el WebKit del sistema para ejecutar el motor de
  ejercicios (convertido a JavaScript antiguo). No necesita Internet.
* Las fichas generadas usan estilos modernos (flexbox, rejilla CSS, variables CSS). Se
  ven mejor en un navegador reciente (en un G5, TenFourFox o similar); el Safari de
  Leopard puede mostrarlas sin algunos adornos.
* El código fuente de la aplicación está en src/main.m; el motor, en resources/engine.html.
