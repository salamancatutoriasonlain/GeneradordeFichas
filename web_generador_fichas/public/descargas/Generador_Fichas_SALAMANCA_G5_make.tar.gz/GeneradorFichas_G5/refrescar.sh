#!/bin/sh
# Hace que Mac OS X vuelva a leer el icono y la información de una aplicación (.app)
APP="$1"
[ -d "$APP" ] || exit 0
touch "$APP" "$APP/Contents" "$APP/Contents/Info.plist" 2>/dev/null
for LS in \
  /System/Library/Frameworks/ApplicationServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
  /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
do
  if [ -x "$LS" ]; then "$LS" -f "$APP" >/dev/null 2>&1; break; fi
done
exit 0
