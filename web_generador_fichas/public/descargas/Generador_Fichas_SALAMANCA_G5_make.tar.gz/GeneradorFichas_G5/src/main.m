/*
 * Generador de Fichas SALAMANCA — versión nativa para Mac OS X 10.5 (Leopard, PowerPC/Intel)
 *
 * Ventana Cocoa sin archivos .nib. El motor de ejercicios (JavaScript ES5) corre dentro de un
 * WebView oculto; la aplicación solo le pasa las opciones y recibe el HTML de la ficha.
 * Compilar con:  make app       Instalar con:  make install
 *
 * Código compatible con Objective-C 1.0/2.0 y gcc 4.0 (sin ARC, sin bloques, sin GCD).
 */
#import <Cocoa/Cocoa.h>
#import <WebKit/WebKit.h>
#include <stdlib.h>
#include <time.h>

static NSColor *Marino(void) { return [NSColor colorWithCalibratedRed:0.0 green:0.12 blue:0.30 alpha:1.0]; }

static NSTextField *Etiqueta(NSView *vista, NSString *texto, NSRect r, CGFloat tam, BOOL negrita, NSColor *color)
{
    NSTextField *t = [[[NSTextField alloc] initWithFrame:r] autorelease];
    [t setStringValue:texto];
    [t setBezeled:NO];
    [t setDrawsBackground:NO];
    [t setEditable:NO];
    [t setSelectable:NO];
    [t setFont:(negrita ? [NSFont boldSystemFontOfSize:tam] : [NSFont systemFontOfSize:tam])];
    if (color != nil) [t setTextColor:color];
    [vista addSubview:t];
    return t;
}

static NSTextField *Campo(NSView *vista, NSString *texto, NSRect r)
{
    NSTextField *t = [[[NSTextField alloc] initWithFrame:r] autorelease];
    [t setStringValue:texto];
    [vista addSubview:t];
    return t;
}

static NSButton *Boton(NSView *vista, NSString *titulo, NSRect r, id destino, SEL accion)
{
    NSButton *b = [[[NSButton alloc] initWithFrame:r] autorelease];
    [b setTitle:titulo];
    [b setBezelStyle:NSRoundedBezelStyle];
    [b setTarget:destino];
    [b setAction:accion];
    [vista addSubview:b];
    return b;
}

static NSPopUpButton *Menu(NSView *vista, NSRect r)
{
    NSPopUpButton *p = [[[NSPopUpButton alloc] initWithFrame:r pullsDown:NO] autorelease];
    [vista addSubview:p];
    return p;
}

/* ------------------------------------------------------------------------------------------- */

@interface Controlador : NSObject
{
    NSWindow *win;
    WebView *motor;
    BOOL motorListo;
    NSPopUpButton *popNivel;
    NSPopUpButton *popDif;
    NSPopUpButton *popModo;
    NSPopUpButton *popInt;
    NSTableView *tabla;
    NSMutableArray *temaIds;
    NSMutableArray *temaNombres;
    NSMutableArray *temaMarca;
    NSTextField *txtN;
    NSTextField *txtSeed;
    NSTextField *txtTitulo;
    NSTextField *txtSub;
    NSTextField *lblEstado;
    NSStepper *stepN;
    NSButton *btGenerar;
    NSButton *btGuardar;
    NSButton *btGuardarSol;
    NSButton *btVerSol;
    NSString *ultimoHTML;
    NSString *ultimoNombre;
    NSString *subAuto;
}
- (void)construirMenu;
- (void)construirVentana;
- (void)estado:(NSString *)msg;
- (void)cargarNiveles;
- (void)cargarTemas;
@end

@implementation Controlador

- (id)init
{
    self = [super init];
    if (self != nil) {
        temaIds = [[NSMutableArray alloc] init];
        temaNombres = [[NSMutableArray alloc] init];
        temaMarca = [[NSMutableArray alloc] init];
        motorListo = NO;
        srandom((unsigned int)time(NULL));
    }
    return self;
}

- (void)dealloc
{
    [temaIds release];
    [temaNombres release];
    [temaMarca release];
    [ultimoHTML release];
    [ultimoNombre release];
    [subAuto release];
    [motor release];
    [win release];
    [super dealloc];
}

/* ---- arranque ---- */

- (void)applicationDidFinishLaunching:(NSNotification *)nota
{
    [self construirMenu];
    [self construirVentana];

    NSString *ruta = [[NSBundle mainBundle] pathForResource:@"engine" ofType:@"html"];
    if (ruta == nil) {
        [self estado:@"Error: falta engine.html dentro de la aplicación."];
        return;
    }
    motor = [[WebView alloc] initWithFrame:NSMakeRect(0, 0, 2, 2) frameName:nil groupName:nil];
    [motor setFrameLoadDelegate:self];
    [[win contentView] addSubview:motor];
    [motor setHidden:YES];
    [[motor mainFrame] loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:ruta]]];
    [self estado:@"Cargando el motor de ejercicios…"];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)app
{
    return YES;
}

- (void)construirMenu
{
    NSMenu *barra = [[[NSMenu alloc] initWithTitle:@""] autorelease];

    NSMenuItem *itApp = [[[NSMenuItem alloc] initWithTitle:@"" action:NULL keyEquivalent:@""] autorelease];
    [barra addItem:itApp];
    NSMenu *mApp = [[[NSMenu alloc] initWithTitle:@"Generador de Fichas"] autorelease];
    [mApp addItemWithTitle:@"Acerca de Generador de Fichas" action:@selector(orderFrontStandardAboutPanel:) keyEquivalent:@""];
    [mApp addItem:[NSMenuItem separatorItem]];
    [mApp addItemWithTitle:@"Ocultar" action:@selector(hide:) keyEquivalent:@"h"];
    [mApp addItem:[NSMenuItem separatorItem]];
    [mApp addItemWithTitle:@"Salir" action:@selector(terminate:) keyEquivalent:@"q"];
    [itApp setSubmenu:mApp];

    NSMenuItem *itEd = [[[NSMenuItem alloc] initWithTitle:@"Edición" action:NULL keyEquivalent:@""] autorelease];
    [barra addItem:itEd];
    NSMenu *mEd = [[[NSMenu alloc] initWithTitle:@"Edición"] autorelease];
    [mEd addItemWithTitle:@"Cortar" action:@selector(cut:) keyEquivalent:@"x"];
    [mEd addItemWithTitle:@"Copiar" action:@selector(copy:) keyEquivalent:@"c"];
    [mEd addItemWithTitle:@"Pegar" action:@selector(paste:) keyEquivalent:@"v"];
    [mEd addItemWithTitle:@"Seleccionar todo" action:@selector(selectAll:) keyEquivalent:@"a"];
    [itEd setSubmenu:mEd];

    [NSApp setMainMenu:barra];
}

- (void)construirVentana
{
    NSRect marco = NSMakeRect(0, 0, 760, 600);
    win = [[NSWindow alloc] initWithContentRect:marco
                                      styleMask:(NSTitledWindowMask | NSClosableWindowMask | NSMiniaturizableWindowMask)
                                        backing:NSBackingStoreBuffered
                                          defer:NO];
    [win setTitle:@"Generador de Fichas · SALAMANCA Tutorías Online"];
    [win setReleasedWhenClosed:NO];
    NSView *v = [win contentView];
    NSColor *marino = Marino();

    /* cabecera con el logotipo */
    NSString *rl = [[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"];
    NSImage *img = (rl != nil) ? [[[NSImage alloc] initWithContentsOfFile:rl] autorelease] : nil;
    if (img != nil) {
        NSImageView *iv = [[[NSImageView alloc] initWithFrame:NSMakeRect(20, 498, 170, 96)] autorelease];
        [iv setImage:img];
        [iv setImageScaling:NSScaleProportionally];
        [v addSubview:iv];
    }
    Etiqueta(v, @"Generador de fichas de matemáticas", NSMakeRect(210, 556, 530, 28), 20, YES, marino);
    Etiqueta(v, @"Fichas y exámenes autocorregibles de 1.º de ESO a 2.º de Bachillerato", NSMakeRect(210, 534, 530, 18), 12, NO, nil);
    Etiqueta(v, @"SALAMANCA Tutorías Online  ·  +34 609 975 502  ·  sosclases@hotmail.com", NSMakeRect(210, 514, 530, 18), 12, NO, marino);

    NSBox *linea = [[[NSBox alloc] initWithFrame:NSMakeRect(20, 492, 720, 1)] autorelease];
    [linea setBoxType:NSBoxSeparator];
    [v addSubview:linea];

    /* columna izquierda: opciones */
    Etiqueta(v, @"Curso", NSMakeRect(20, 464, 200, 16), 12, YES, marino);
    popNivel = Menu(v, NSMakeRect(20, 438, 340, 26));
    [popNivel setTarget:self];
    [popNivel setAction:@selector(cambioNivel:)];

    Etiqueta(v, @"Dificultad", NSMakeRect(20, 408, 150, 16), 12, YES, marino);
    popDif = Menu(v, NSMakeRect(20, 382, 160, 26));
    [popDif addItemWithTitle:@"Básica"];     [[popDif lastItem] setTag:1];
    [popDif addItemWithTitle:@"Media"];      [[popDif lastItem] setTag:2];
    [popDif addItemWithTitle:@"Avanzada"];   [[popDif lastItem] setTag:3];
    [popDif addItemWithTitle:@"Mezclada"];   [[popDif lastItem] setTag:0];
    [popDif selectItemAtIndex:1];

    Etiqueta(v, @"Tipo", NSMakeRect(200, 408, 150, 16), 12, YES, marino);
    popModo = Menu(v, NSMakeRect(200, 382, 160, 26));
    [popModo addItemWithTitle:@"Ficha de ejercicios"];  [[popModo lastItem] setTag:0];
    [popModo addItemWithTitle:@"Examen"];               [[popModo lastItem] setTag:1];

    Etiqueta(v, @"Nº de ejercicios", NSMakeRect(20, 350, 150, 16), 12, YES, marino);
    txtN = Campo(v, @"8", NSMakeRect(20, 324, 56, 24));
    stepN = [[[NSStepper alloc] initWithFrame:NSMakeRect(80, 324, 19, 27)] autorelease];
    [stepN setMinValue:1];
    [stepN setMaxValue:30];
    [stepN setIncrement:1];
    [stepN setValueWraps:NO];
    [stepN setIntValue:8];
    [stepN setTarget:self];
    [stepN setAction:@selector(pasoN:)];
    [v addSubview:stepN];

    Etiqueta(v, @"Reintentos («Rehacer»)", NSMakeRect(200, 350, 160, 16), 12, YES, marino);
    popInt = Menu(v, NSMakeRect(200, 322, 80, 26));
    [popInt addItemWithTitle:@"1"];  [[popInt lastItem] setTag:1];
    [popInt addItemWithTitle:@"2"];  [[popInt lastItem] setTag:2];
    [popInt addItemWithTitle:@"3"];  [[popInt lastItem] setTag:3];
    [popInt addItemWithTitle:@"5"];  [[popInt lastItem] setTag:5];
    [popInt selectItemAtIndex:3];

    Etiqueta(v, @"Semilla (misma semilla = misma ficha)", NSMakeRect(20, 292, 340, 16), 12, YES, marino);
    txtSeed = Campo(v, [NSString stringWithFormat:@"%ld", (long)(100000 + random() % 900000)], NSMakeRect(20, 266, 130, 24));
    Boton(v, @"Nueva semilla", NSMakeRect(158, 264, 120, 28), self, @selector(nuevaSemilla:));

    Etiqueta(v, @"Título de la ficha", NSMakeRect(20, 236, 340, 16), 12, YES, marino);
    txtTitulo = Campo(v, @"Ejercicios de Matemáticas", NSMakeRect(20, 210, 340, 24));

    Etiqueta(v, @"Subtítulo (curso, tema…)", NSMakeRect(20, 180, 340, 16), 12, YES, marino);
    txtSub = Campo(v, @"", NSMakeRect(20, 154, 340, 24));

    btGenerar = Boton(v, @"Generar y abrir en el navegador", NSMakeRect(20, 108, 340, 32), self, @selector(generar:));
    [btGenerar setKeyEquivalent:@"\r"];
    btGuardar = Boton(v, @"Guardar ficha…", NSMakeRect(20, 72, 165, 28), self, @selector(guardarFicha:));
    btGuardarSol = Boton(v, @"Guardar soluciones…", NSMakeRect(195, 72, 165, 28), self, @selector(guardarSoluciones:));
    btVerSol = Boton(v, @"Abrir soluciones en el navegador", NSMakeRect(20, 38, 340, 28), self, @selector(verSoluciones:));
    [btGuardar setEnabled:NO];
    [btGuardarSol setEnabled:NO];
    [btVerSol setEnabled:NO];

    lblEstado = Etiqueta(v, @"", NSMakeRect(20, 6, 720, 28), 11, NO, nil);
    [[lblEstado cell] setWraps:YES];

    /* columna derecha: temas */
    Etiqueta(v, @"Temas (marca los que quieras)", NSMakeRect(390, 464, 350, 16), 12, YES, marino);
    NSScrollView *sv = [[[NSScrollView alloc] initWithFrame:NSMakeRect(390, 78, 350, 380)] autorelease];
    [sv setHasVerticalScroller:YES];
    [sv setBorderType:NSBezelBorder];
    tabla = [[[NSTableView alloc] initWithFrame:NSMakeRect(0, 0, 330, 380)] autorelease];
    NSTableColumn *c1 = [[[NSTableColumn alloc] initWithIdentifier:@"chk"] autorelease];
    NSButtonCell *bc = [[[NSButtonCell alloc] init] autorelease];
    [bc setButtonType:NSSwitchButton];
    [bc setTitle:@""];
    [bc setControlSize:NSSmallControlSize];
    [c1 setDataCell:bc];
    [c1 setWidth:24];
    [c1 setMinWidth:24];
    [c1 setMaxWidth:24];
    [c1 setEditable:YES];
    NSTableColumn *c2 = [[[NSTableColumn alloc] initWithIdentifier:@"nombre"] autorelease];
    [c2 setWidth:296];
    [c2 setEditable:NO];
    [[c2 dataCell] setFont:[NSFont systemFontOfSize:12]];
    [tabla addTableColumn:c1];
    [tabla addTableColumn:c2];
    [tabla setHeaderView:nil];
    [tabla setRowHeight:18];
    [tabla setDataSource:self];
    [tabla setDelegate:self];
    [sv setDocumentView:tabla];
    [v addSubview:sv];
    Boton(v, @"Todos", NSMakeRect(390, 44, 100, 28), self, @selector(marcarTodos:));
    Boton(v, @"Ninguno", NSMakeRect(496, 44, 100, 28), self, @selector(marcarNinguno:));

    [win center];
    [win makeKeyAndOrderFront:nil];
    [NSApp activateIgnoringOtherApps:YES];
}

/* ---- comunicación con el motor JavaScript ---- */

- (NSString *)js:(NSString *)funcion args:(NSArray *)args
{
    if (!motorListo) return nil;
    id r = [[motor windowScriptObject] callWebScriptMethod:funcion withArguments:args];
    if ([r isKindOfClass:[NSString class]]) return (NSString *)r;
    return nil;
}

- (void)webView:(WebView *)sender didFinishLoadForFrame:(WebFrame *)frame
{
    if (frame != [sender mainFrame]) return;
    motorListo = YES;
    NSString *ok = [self js:@"apiListo" args:[NSArray array]];
    if (ok == nil || ![ok isEqualToString:@"OK"]) {
        motorListo = NO;
        [self estado:[NSString stringWithFormat:@"El motor de ejercicios no ha arrancado: %@", (ok != nil ? ok : @"sin respuesta")]];
        return;
    }
    [self cargarNiveles];
    [self estado:@"Listo. Elige curso y temas, y pulsa «Generar»."];
}

- (void)webView:(WebView *)sender didFailLoadWithError:(NSError *)error forFrame:(WebFrame *)frame
{
    [self estado:[NSString stringWithFormat:@"No se pudo cargar el motor: %@", [error localizedDescription]]];
}

- (void)webView:(WebView *)sender didFailProvisionalLoadWithError:(NSError *)error forFrame:(WebFrame *)frame
{
    [self estado:[NSString stringWithFormat:@"No se pudo cargar el motor: %@", [error localizedDescription]]];
}

- (void)cargarNiveles
{
    NSString *s = [self js:@"apiNiveles" args:[NSArray array]];
    if (s == nil) return;
    NSArray *lineas = [s componentsSeparatedByString:@"\n"];
    NSUInteger i;
    [popNivel removeAllItems];
    for (i = 0; i < [lineas count]; i++) {
        NSArray *p = [[lineas objectAtIndex:i] componentsSeparatedByString:@"\t"];
        if ([p count] < 2) continue;
        [popNivel addItemWithTitle:[p objectAtIndex:1]];
        [[popNivel lastItem] setTag:[[p objectAtIndex:0] intValue]];
    }
    [popNivel selectItemWithTag:2];
    [self cargarTemas];
}

- (void)cargarTemas
{
    int nivel = (int)[[popNivel selectedItem] tag];
    NSString *s = [self js:@"apiTemas" args:[NSArray arrayWithObject:[NSNumber numberWithInt:nivel]]];
    [temaIds removeAllObjects];
    [temaNombres removeAllObjects];
    [temaMarca removeAllObjects];
    if (s != nil && [s length] > 0) {
        NSArray *lineas = [s componentsSeparatedByString:@"\n"];
        NSUInteger i;
        for (i = 0; i < [lineas count]; i++) {
            NSArray *p = [[lineas objectAtIndex:i] componentsSeparatedByString:@"\t"];
            if ([p count] < 2) continue;
            [temaIds addObject:[p objectAtIndex:0]];
            [temaNombres addObject:[p objectAtIndex:1]];
            [temaMarca addObject:[NSNumber numberWithBool:YES]];
        }
    }
    [tabla reloadData];
    NSString *nombre = [[popNivel selectedItem] title];
    if (subAuto == nil || [[txtSub stringValue] length] == 0 || [[txtSub stringValue] isEqualToString:subAuto]) {
        [txtSub setStringValue:nombre];
    }
    [subAuto release];
    subAuto = [nombre copy];
}

/* ---- tabla de temas (origen de datos) ---- */

- (NSInteger)numberOfRowsInTableView:(NSTableView *)t
{
    return (NSInteger)[temaIds count];
}

- (id)tableView:(NSTableView *)t objectValueForTableColumn:(NSTableColumn *)col row:(NSInteger)row
{
    if ([[col identifier] isEqualToString:@"chk"]) return [temaMarca objectAtIndex:row];
    return [temaNombres objectAtIndex:row];
}

- (void)tableView:(NSTableView *)t setObjectValue:(id)obj forTableColumn:(NSTableColumn *)col row:(NSInteger)row
{
    if ([[col identifier] isEqualToString:@"chk"]) {
        [temaMarca replaceObjectAtIndex:row withObject:[NSNumber numberWithBool:[obj boolValue]]];
    }
}

/* ---- acciones ---- */

- (void)cambioNivel:(id)s { [self cargarTemas]; }

- (void)pasoN:(id)s { [txtN setIntValue:[stepN intValue]]; }

- (void)nuevaSemilla:(id)s
{
    [txtSeed setStringValue:[NSString stringWithFormat:@"%ld", (long)(100000 + random() % 900000)]];
}

- (void)marcarTodos:(id)s
{
    NSUInteger i;
    for (i = 0; i < [temaMarca count]; i++) [temaMarca replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:YES]];
    [tabla reloadData];
}

- (void)marcarNinguno:(id)s
{
    NSUInteger i;
    for (i = 0; i < [temaMarca count]; i++) [temaMarca replaceObjectAtIndex:i withObject:[NSNumber numberWithBool:NO]];
    [tabla reloadData];
}

- (void)estado:(NSString *)msg
{
    [lblEstado setStringValue:msg];
}

- (NSString *)jsonEsc:(NSString *)s
{
    NSMutableString *m = [NSMutableString stringWithString:s];
    [m replaceOccurrencesOfString:@"\\" withString:@"\\\\" options:0 range:NSMakeRange(0, [m length])];
    [m replaceOccurrencesOfString:@"\"" withString:@"\\\"" options:0 range:NSMakeRange(0, [m length])];
    [m replaceOccurrencesOfString:@"\n" withString:@" " options:0 range:NSMakeRange(0, [m length])];
    [m replaceOccurrencesOfString:@"\r" withString:@" " options:0 range:NSMakeRange(0, [m length])];
    [m replaceOccurrencesOfString:@"\t" withString:@" " options:0 range:NSMakeRange(0, [m length])];
    return m;
}

- (NSString *)escribirTemporal:(NSString *)html nombre:(NSString *)nombre
{
    NSString *dir = [NSTemporaryDirectory() stringByAppendingPathComponent:@"FichasSALAMANCA"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:NULL];
    NSString *ruta = [dir stringByAppendingPathComponent:nombre];
    NSError *err = nil;
    if (![html writeToFile:ruta atomically:YES encoding:NSUTF8StringEncoding error:&err]) {
        [self estado:[NSString stringWithFormat:@"No se pudo escribir el archivo: %@", [err localizedDescription]]];
        return nil;
    }
    return ruta;
}

/* Genera la ficha y la deja en ultimoHTML. Devuelve YES si todo fue bien. */
- (BOOL)generarFicha
{
    if (!motorListo) { [self estado:@"El motor todavía se está cargando; espera un momento."]; return NO; }

    NSMutableString *ids = [NSMutableString string];
    NSUInteger i;
    for (i = 0; i < [temaIds count]; i++) {
        if ([[temaMarca objectAtIndex:i] boolValue]) {
            if ([ids length] > 0) [ids appendString:@","];
            [ids appendFormat:@"\"%@\"", [temaIds objectAtIndex:i]];
        }
    }
    if ([ids length] == 0) { [self estado:@"Marca al menos un tema."]; return NO; }

    int n = [txtN intValue];
    if (n < 1) n = 1;
    if (n > 30) n = 30;
    [txtN setIntValue:n];
    [stepN setIntValue:n];
    long seed = [txtSeed intValue];
    if (seed <= 0) { seed = 100000 + random() % 900000; [txtSeed setStringValue:[NSString stringWithFormat:@"%ld", seed]]; }
    NSString *titulo = [[txtTitulo stringValue] length] > 0 ? [txtTitulo stringValue] : @"Ejercicios de Matemáticas";
    NSString *json = [NSString stringWithFormat:
        @"{\"nivel\":%d,\"temas\":[%@],\"dif\":%d,\"n\":%d,\"seed\":%ld,\"modo\":\"%@\",\"titulo\":\"%@\",\"subtitulo\":\"%@\",\"intentos\":%d}",
        (int)[[popNivel selectedItem] tag], ids, (int)[[popDif selectedItem] tag], n, seed,
        ([[popModo selectedItem] tag] == 1 ? @"examen" : @"ficha"),
        [self jsonEsc:titulo], [self jsonEsc:[txtSub stringValue]], (int)[[popInt selectedItem] tag]];

    NSString *res = [self js:@"apiGenerar" args:[NSArray arrayWithObject:json]];
    if (res == nil) { [self estado:@"El motor no respondió."]; return NO; }
    if (![res hasPrefix:@"OK\n"]) {
        [self estado:[NSString stringWithFormat:@"No se pudo generar: %@", [res length] > 4 ? [res substringFromIndex:4] : res]];
        return NO;
    }
    [ultimoHTML release];
    ultimoHTML = [[res substringFromIndex:3] retain];
    [ultimoNombre release];
    NSString *nom = [self js:@"apiNombre" args:[NSArray arrayWithObject:@"ficha"]];
    ultimoNombre = [(nom != nil && [nom length] > 0 ? nom : @"Ficha.html") retain];
    [btGuardar setEnabled:YES];
    [btGuardarSol setEnabled:YES];
    [btVerSol setEnabled:YES];
    return YES;
}

- (NSString *)htmlSoluciones:(NSString **)nombre
{
    NSString *res = [self js:@"apiSoluciones" args:[NSArray array]];
    if (res == nil || ![res hasPrefix:@"OK\n"]) { [self estado:@"Primero genera una ficha."]; return nil; }
    NSString *nom = [self js:@"apiNombre" args:[NSArray arrayWithObject:@"sol"]];
    *nombre = (nom != nil && [nom length] > 0) ? nom : @"Soluciones.html";
    return [res substringFromIndex:3];
}

- (void)generar:(id)s
{
    if (![self generarFicha]) return;
    NSString *ruta = [self escribirTemporal:ultimoHTML nombre:ultimoNombre];
    if (ruta == nil) return;
    [[NSWorkspace sharedWorkspace] openFile:ruta];
    [self estado:[NSString stringWithFormat:@"Ficha generada (semilla %@) y abierta en el navegador. Puedes guardarla con «Guardar ficha…».", [txtSeed stringValue]]];
}

- (void)guardarTexto:(NSString *)html nombre:(NSString *)nombre
{
    NSSavePanel *sp = [NSSavePanel savePanel];
    [sp setRequiredFileType:@"html"];
    [sp setCanCreateDirectories:YES];
    if ([sp runModalForDirectory:nil file:nombre] == NSOKButton) {
        NSError *err = nil;
        if ([html writeToFile:[sp filename] atomically:YES encoding:NSUTF8StringEncoding error:&err]) {
            [self estado:[NSString stringWithFormat:@"Guardado: %@", [sp filename]]];
        } else {
            [self estado:[NSString stringWithFormat:@"No se pudo guardar: %@", [err localizedDescription]]];
        }
    }
}

- (void)guardarFicha:(id)s
{
    if (ultimoHTML == nil) return;
    [self guardarTexto:ultimoHTML nombre:ultimoNombre];
}

- (void)guardarSoluciones:(id)s
{
    NSString *nombre = nil;
    NSString *html = [self htmlSoluciones:&nombre];
    if (html == nil) return;
    [self guardarTexto:html nombre:nombre];
}

- (void)verSoluciones:(id)s
{
    NSString *nombre = nil;
    NSString *html = [self htmlSoluciones:&nombre];
    if (html == nil) return;
    NSString *ruta = [self escribirTemporal:html nombre:nombre];
    if (ruta != nil) {
        [[NSWorkspace sharedWorkspace] openFile:ruta];
        [self estado:@"Soluciones abiertas en el navegador (solo para el profesor)."];
    }
}

@end

/* ------------------------------------------------------------------------------------------- */

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    [NSApplication sharedApplication];
    Controlador *c = [[Controlador alloc] init];
    [NSApp setDelegate:c];
    [NSApp run];
    [c release];
    [pool release];
    return 0;
}
